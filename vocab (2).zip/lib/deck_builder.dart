import 'dart:math';

import 'package:flutter/services.dart' show rootBundle;

import 'ai_service.dart';
import 'db.dart';

/// Строит колоду из assets/wordlist.txt. Слова, которые уже есть, пропускаются.
/// Каждый пакет сохраняется сразу, поэтому после остановки или ошибки
/// повторный запуск продолжит с того места, где остановились.
class DeckBuilder {
  static const batchSize = 40;

  final Db db;
  final AiService ai;
  bool _cancelled = false;

  DeckBuilder({required this.db, required this.ai});

  void cancel() => _cancelled = true;

  Future<int> run({required void Function(String) onStatus}) async {
    final raw = await rootBundle.loadString('assets/wordlist.txt');
    final all = raw
        .split('\n')
        .map((l) => l.trim().toLowerCase())
        .where((l) => l.isNotEmpty && !l.startsWith('#'))
        .toSet()
        .toList();

    final existing = await db.allWordStrings();
    final pending = all.where((w) => !existing.contains(w)).toList();

    if (pending.isEmpty) {
      onStatus('Все слова из списка уже в колоде');
      return 0;
    }

    var added = 0;
    for (var i = 0; i < pending.length && !_cancelled; i += batchSize) {
      final end = min(i + batchSize, pending.length);
      final batch = pending.sublist(i, end);
      onStatus('Слова ${i + 1}–$end из ${pending.length}');

      final words = await ai.enrichWords(batch);
      await db.seed(words);
      added += words.length;
    }

    onStatus(_cancelled
        ? 'Остановлено. Добавлено: $added'
        : 'Готово. Добавлено: $added');
    return added;
  }
}
