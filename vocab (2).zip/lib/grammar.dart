import 'package:flutter/material.dart';

/// Упражнение: prompt с пропуском, answer — правильный ответ.
/// Допустимые варианты перечисляются через «|».
class GrammarExercise {
  final String prompt;
  final String answer;
  const GrammarExercise(this.prompt, this.answer);
}

class GrammarTopic {
  final String level;
  final String title;
  final String rule;
  final List<String> examples;
  final List<GrammarExercise> exercises;

  const GrammarTopic({
    required this.level,
    required this.title,
    required this.rule,
    required this.examples,
    required this.exercises,
  });
}

/// Добавляйте темы сюда в том же формате.
const grammarTopics = <GrammarTopic>[
  GrammarTopic(
    level: 'B1',
    title: 'Present Perfect и Past Simple',
    rule: 'Present Perfect (have/has + V3) связывает прошлое с настоящим: опыт, '
        'результат, период до сих пор. Past Simple — завершённое действие в '
        'названный или подразумеваемый момент в прошлом.',
    examples: [
      'I have lost my keys. (ключей сейчас нет)',
      'I lost my keys yesterday. (назван момент)',
    ],
    exercises: [
      GrammarExercise('I ___ (never / be) to Japan.', 'have never been'),
      GrammarExercise('We ___ (move) to London in 2019.', 'moved'),
      GrammarExercise('She ___ (already / finish) the report.',
          'has already finished'),
    ],
  ),
  GrammarTopic(
    level: 'B1',
    title: 'Present Perfect Continuous',
    rule: 'have/has been + V-ing: действие началось в прошлом и длится до сих пор, '
        'или только что закончилось, а результат виден. Акцент на процесс.',
    examples: [
      'I have been working here since 2020.',
      'You look tired. Have you been running?',
    ],
    exercises: [
      GrammarExercise('It ___ (rain) all day.', 'has been raining'),
      GrammarExercise('How long ___ you ___ (learn) English?',
          'have been learning|have you been learning'),
      GrammarExercise('I am out of breath because I ___ (run).',
          'have been running'),
    ],
  ),
  GrammarTopic(
    level: 'B1',
    title: 'Past Perfect',
    rule: 'had + V3: действие произошло раньше другого действия в прошлом. Часто с '
        'before, after, by the time, already, never.',
    examples: [
      'When I arrived, the film had already started.',
      'She said she had never seen snow.',
    ],
    exercises: [
      GrammarExercise('He ___ (leave) before we got there.', 'had left'),
      GrammarExercise('She said she ___ (never / see) snow.',
          'had never seen'),
      GrammarExercise('By 2010 they ___ (build) the bridge.', 'had built'),
    ],
  ),
  GrammarTopic(
    level: 'B1',
    title: 'Future: will, going to, Present Continuous',
    rule: 'will — решение в момент речи и прогноз без явных признаков. going to — '
        'заранее принятое намерение или очевидный признак. Present Continuous — '
        'договорённость с конкретным временем и местом.',
    examples: [
      'I think I will help you. (решение сейчас)',
      'Look at those clouds. It is going to rain. (признак)',
      'We are meeting Anna at 7. (договорённость)',
    ],
    exercises: [
      GrammarExercise('Look at those clouds! It ___ (rain).', 'is going to rain'),
      GrammarExercise('I think I ___ (help) you with that.', 'will help'),
      GrammarExercise('We ___ (meet) Anna at 7 tomorrow.', 'are meeting'),
    ],
  ),
  GrammarTopic(
    level: 'B1',
    title: 'Условные 0, 1, 2',
    rule: 'Ноль: факты (If + Present, Present). Первый: реальное будущее '
        '(If + Present, will + V). Второй: нереальное настоящее или будущее '
        '(If + Past, would + V). Во втором типе was/were для всех лиц.',
    examples: [
      'If you heat ice, it melts.',
      'If it rains, we will stay home.',
      'If I were rich, I would travel.',
    ],
    exercises: [
      GrammarExercise('If you heat ice, it ___ (melt).', 'melts'),
      GrammarExercise('If it rains, we ___ (stay) home.', 'will stay'),
      GrammarExercise('If I ___ (be) rich, I would travel.', 'were|was'),
    ],
  ),
  GrammarTopic(
    level: 'B2',
    title: 'Условные 3 и смешанные',
    rule: 'Третий тип: нереальное прошлое (If + Past Perfect, would have + V3). '
        'Смешанный: прошлое условие и настоящий результат, или наоборот.',
    examples: [
      'If I had studied harder, I would have passed.',
      'If I had taken that job, I would be living in Paris now.',
    ],
    exercises: [
      GrammarExercise('If I ___ (study) harder, I would have passed.',
          'had studied'),
      GrammarExercise(
          'If I had taken the job, I ___ (live) in Paris now.',
          'would be living'),
      GrammarExercise('I wish I ___ (know) that earlier.', 'had known'),
    ],
  ),
  GrammarTopic(
    level: 'B1',
    title: 'Страдательный залог (Passive)',
    rule: 'be + V3. Время определяется глаголом be. Агент (by ...) указывают, '
        'если он важен. Passive часто используют, когда действующее лицо неизвестно '
        'или неважно.',
    examples: [
      'The letter was sent yesterday.',
      'The new bridge will be finished next year.',
    ],
    exercises: [
      GrammarExercise('The letter ___ (send) yesterday.', 'was sent'),
      GrammarExercise('The house ___ (build) in 1950.', 'was built'),
      GrammarExercise('The new bridge ___ (finish) next year.',
          'will be finished'),
    ],
  ),
  GrammarTopic(
    level: 'B2',
    title: 'Модальные для предположений',
    rule: 'Настоящее: must be (уверен), might/may/could be (возможно), can\'t be '
        '(не может быть). Прошлое: must have, might have, can\'t have + V3.',
    examples: [
      'He must be at work. His car is outside.',
      'It might rain later.',
      'They can\'t have seen me. They didn\'t say hello.',
    ],
    exercises: [
      GrammarExercise('He ___ (be) at work now, his car is outside.',
          'must be'),
      GrammarExercise('I am not sure, but it ___ (rain) later.',
          'might rain|may rain|could rain'),
      GrammarExercise('They ___ (not / get) my message, they did not reply.',
          'might not have got|may not have got|might not have gotten'),
    ],
  ),
  GrammarTopic(
    level: 'B2',
    title: 'Косвенная речь',
    rule: 'Сдвиг времени назад: Present → Past, Past → Past Perfect, will → would, '
        'can → could. Вопросы — без инверсии, с if/whether для да/нет. Приказы — '
        'told me to/not to.',
    examples: [
      '"I am tired." → She said she was tired.',
      '"Will you come?" → He asked me if I would come.',
    ],
    exercises: [
      GrammarExercise('"I am tired," she said. → She said she ___ tired.',
          'was'),
      GrammarExercise('"Will you come?" he asked me. → He asked me if I ___ come.',
          'would'),
      GrammarExercise('"Don\'t touch it," the guard said. → The guard told me '
          '___ touch it.', 'not to'),
    ],
  ),
  GrammarTopic(
    level: 'B1',
    title: 'Артикли',
    rule: 'a/an — впервые упоминаемый предмет или любой представитель класса. '
        'the — известный собеседникам, единственный в своём роде, или уже упомянутый. '
        'Нулевой артикль — общие понятия во множественном числе, названия языков '
        'и многих дисциплин.',
    examples: [
      'I am reading a book. The book is about history.',
      'The sun rises in the east. Life is short.',
    ],
    exercises: [
      GrammarExercise("I'm reading ___ book about history.", 'a|the'),
      GrammarExercise('___ sun rises in the east.', 'The|the'),
      GrammarExercise('She plays ___ piano very well.', 'the'),
    ],
  ),
  GrammarTopic(
    level: 'B1',
    title: 'Герундий и инфинитив',
    rule: 'После enjoy, finish, avoid, suggest — только герундий. После decide, '
        'hope, plan, want — только инфинитив. Некоторые глаголы меняют смысл: stop '
        'doing (перестать делать) и stop to do (остановиться, чтобы сделать).',
    examples: [
      'I enjoy swimming. I decided to leave.',
      'He stopped smoking. He stopped to buy milk.',
    ],
    exercises: [
      GrammarExercise('I enjoy ___ (swim).', 'swimming'),
      GrammarExercise('I decided ___ (leave).', 'to leave'),
      GrammarExercise('He stopped ___ (to buy) milk on the way.',
          'to buy'),
    ],
  ),
  GrammarTopic(
    level: 'B2',
    title: 'Относительные придаточные',
    rule: 'who — для людей, which — для предметов, that — для обоих (в определяющих), '
        'where — для мест, whose — принадлежность. Запятые — в не определяющих '
        'придаточных, и тогда that не используется.',
    examples: [
      'The man who lives next door is a doctor.',
      'This is the house where I grew up.',
    ],
    exercises: [
      GrammarExercise('The man ___ lives next door is a doctor.',
          'who|that'),
      GrammarExercise('This is the house ___ I grew up.', 'where|that|in which'),
      GrammarExercise('Anyone ___ wants to join can register.', 'who|that'),
    ],
  ),
  GrammarTopic(
    level: 'C1',
    title: 'Инверсия',
    rule: 'После отрицательных наречий (never, rarely, hardly, not only, '
        'no sooner) вспомогательный глагол ставится перед подлежащим. Используется '
        'в книжной речи и для выразительности.',
    examples: [
      'Never have I seen such a view.',
      'Hardly had I arrived when it started raining.',
    ],
    exercises: [
      GrammarExercise('Never ___ I seen such a view.', 'have'),
      GrammarExercise('Not only ___ she smart, but also kind.', 'is'),
      GrammarExercise('Hardly ___ I arrived when it started raining.', 'had'),
    ],
  ),
  GrammarTopic(
    level: 'C1',
    title: 'Wish и if only',
    rule: 'wish/if only + Past Simple — сожаление о настоящем. wish/if only + '
        'Past Perfect — сожаление о прошлом. wish + would — желание, чтобы что-то '
        'изменилось (часто раздражение).',
    examples: [
      'I wish I had more time.',
      'If only I had listened to you!',
    ],
    exercises: [
      GrammarExercise('I wish I ___ (have) more time.', 'had'),
      GrammarExercise('I wish I ___ (not / say) that.', "hadn't said|had not said"),
      GrammarExercise('If only I ___ (listen) to you!', 'had listened'),
    ],
  ),
  GrammarTopic(
    level: 'C1',
    title: 'Каузатив: have/get something done',
    rule: 'have/get + объект + V3 — кто-то делает что-то для нас. Вместо "я '
        'сам делаю" используем "я это делаю через другого".',
    examples: [
      'I had my car repaired last week.',
      'I need to get my hair cut.',
    ],
    exercises: [
      GrammarExercise('I need to ___ (cut) my hair.', 'have my hair cut|get my hair cut'),
      GrammarExercise('She had her car ___ (repair).', 'repaired'),
      GrammarExercise('He got his phone ___ (fix).', 'fixed'),
    ],
  ),
  GrammarTopic(
    level: 'B2',
    title: 'Фразовые глаголы: базовые',
    rule: 'Глагол + предлог или наречие меняет значение. Многие фразовые глаголы '
        'раздельные: turn the light off, но не в местоимении: turn it off. Для '
        'каждого выучивайте целиком, с примером.',
    examples: [
      'Please turn off the light.',
      'Look up the word in a dictionary.',
      'She gave up smoking last year.',
    ],
    exercises: [
      GrammarExercise('Please turn ___ the light.', 'off'),
      GrammarExercise('I need to look ___ this word.', 'up'),
      GrammarExercise('She gave ___ smoking last year.', 'up'),
    ],
  ),
];

class GrammarScreen extends StatelessWidget {
  const GrammarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Грамматика')),
      body: ListView.separated(
        itemCount: grammarTopics.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final t = grammarTopics[i];
          return ListTile(
            leading: Text(t.level),
            title: Text(t.title),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => GrammarTopicScreen(topic: t)),
            ),
          );
        },
      ),
    );
  }
}

class GrammarTopicScreen extends StatelessWidget {
  final GrammarTopic topic;
  const GrammarTopicScreen({super.key, required this.topic});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text(topic.title)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(topic.rule, style: theme.bodyLarge),
          const SizedBox(height: 12),
          for (final e in topic.examples)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text('• $e', style: theme.bodyMedium),
            ),
          const SizedBox(height: 20),
          Text('Упражнения', style: theme.titleMedium),
          const SizedBox(height: 8),
          for (var i = 0; i < topic.exercises.length; i++)
            _ExerciseTile(number: i + 1, exercise: topic.exercises[i]),
        ],
      ),
    );
  }
}

class _ExerciseTile extends StatefulWidget {
  final int number;
  final GrammarExercise exercise;
  const _ExerciseTile({required this.number, required this.exercise});

  @override
  State<_ExerciseTile> createState() => _ExerciseTileState();
}

class _ExerciseTileState extends State<_ExerciseTile> {
  final _controller = TextEditingController();
  bool? _ok;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  static String _norm(String s) =>
      s.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

  void _check() {
    final typed = _norm(_controller.text);
    final ok = widget.exercise.answer
        .split('|')
        .any((a) => _norm(a) == typed);
    setState(() => _ok = ok);
  }

  @override
  Widget build(BuildContext context) {
    final shown = widget.exercise.answer.split('|').first;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${widget.number}. ${widget.exercise.prompt}'),
            const SizedBox(height: 8),
            TextField(
              controller: _controller,
              decoration: const InputDecoration(
                hintText: 'Ваш ответ',
                border: OutlineInputBorder(),
                isDense: true,
              ),
              onSubmitted: (_) => _check(),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                FilledButton(onPressed: _check, child: const Text('Проверить')),
                const SizedBox(width: 12),
                if (_ok == true) const Text('Верно ✓'),
                if (_ok == false) Expanded(child: Text('Верно: $shown')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
