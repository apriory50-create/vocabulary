import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Ключ API и название модели хранятся только на устройстве.
/// Оба настраиваются в приложении, в код и в git ничего не попадает.
class SecureStore {
  static const _storage = FlutterSecureStorage();
  static const _apiKeyName = 'anthropic_api_key';
  static const _modelName = 'anthropic_model';
  static const defaultModel = 'claude-haiku-5-5';

  Future<String?> readApiKey() => _storage.read(key: _apiKeyName);

  Future<void> writeApiKey(String key) =>
      _storage.write(key: _apiKeyName, value: key.trim());

  Future<void> deleteApiKey() => _storage.delete(key: _apiKeyName);

  Future<String> readModel() async {
    final m = await _storage.read(key: _modelName);
    return (m == null || m.isEmpty) ? defaultModel : m;
  }

  Future<void> writeModel(String model) =>
      _storage.write(key: _modelName, value: model.trim());
}
