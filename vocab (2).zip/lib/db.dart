import 'dart:convert';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'seed.dart';
import 'srs.dart';

class WordRow {
  final int id;
  final String word;
  final String translation;
  final List<String> examples;
  final CardState state;

  WordRow({
    required this.id,
    required this.word,
    required this.translation,
    required this.examples,
    required this.state,
  });

  factory WordRow.fromMap(Map<String, Object?> m) => WordRow(
        id: m['id'] as int,
        word: m['word'] as String,
        translation: m['translation'] as String,
        examples: (jsonDecode(m['examples'] as String) as List).cast<String>(),
        state: CardState(
          stability: (m['stability'] as num).toDouble(),
          difficulty: (m['difficulty'] as num).toDouble(),
          lastMs: m['last_ms'] as int,
          dueMs: m['due_ms'] as int,
          reps: m['reps'] as int,
          lapses: m['lapses'] as int,
        ),
      );
}

class Db {
  static const _version = 3;
  late final Database _db;

  Future<void> open() async {
    _db = await openDatabase(
      join(await getDatabasesPath(), 'vocab.db'),
      version: _version,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE words (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            word        TEXT UNIQUE NOT NULL,
            translation TEXT NOT NULL,
            examples    TEXT NOT NULL,
            stability   REAL NOT NULL DEFAULT 0,
            difficulty  REAL NOT NULL DEFAULT 5,
            last_ms     INTEGER NOT NULL DEFAULT 0,
            due_ms      INTEGER NOT NULL DEFAULT 0,
            reps        INTEGER NOT NULL DEFAULT 0,
            lapses      INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await _createAiCache(db);
      },
      onUpgrade: (db, oldVersion, _) async {
        // v2 добавляла колонку mnemonic, она больше не используется.
        if (oldVersion < 3) await _createAiCache(db);
      },
    );
  }

  Future<void> _createAiCache(Database db) => db.execute('''
        CREATE TABLE IF NOT EXISTS ai_cache (
          key  TEXT PRIMARY KEY,
          text TEXT NOT NULL
        )
      ''');

  /// Добавляет слова, уже существующие пропускаются.
  Future<void> seed(List<SeedWord> words) async {
    final batch = _db.batch();
    for (final w in words) {
      batch.insert(
        'words',
        {
          'word': w.word.toLowerCase(),
          'translation': w.translation,
          'examples': jsonEncode(w.examples),
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    }
    await batch.commit(noResult: true);
  }

  Future<Set<String>> allWordStrings() async {
    final rows = await _db.query('words', columns: ['word']);
    return rows.map((r) => (r['word'] as String).toLowerCase()).toSet();
  }

  Future<int> countWords() async {
    final rows = await _db.rawQuery('SELECT COUNT(*) AS c FROM words');
    return Sqflite.firstIntValue(rows) ?? 0;
  }

  Future<List<WordRow>> dueWords(int nowMs, {int limit = 20}) async {
    final rows = await _db.query(
      'words',
      where: 'due_ms <= ?',
      whereArgs: [nowMs],
      orderBy: 'due_ms',
      limit: limit,
    );
    return rows.map(WordRow.fromMap).toList();
  }

  Future<void> saveReview(int id, CardState s) async {
    await _db.update(
      'words',
      {
        'stability': s.stability,
        'difficulty': s.difficulty,
        'last_ms': s.lastMs,
        'due_ms': s.dueMs,
        'reps': s.reps,
        'lapses': s.lapses,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<String?> getAi(String key) async {
    final rows = await _db.query(
      'ai_cache',
      columns: ['text'],
      where: 'key = ?',
      whereArgs: [key],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first['text'] as String;
  }

  Future<void> putAi(String key, String text) async {
    await _db.insert(
      'ai_cache',
      {'key': key, 'text': text},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }
}
