import 'dart:convert';

import 'package:http/http.dart' as http;

import 'db.dart';
import 'secure_store.dart';
import 'seed.dart';

class AiException implements Exception {
  final String message;
  AiException(this.message);

  @override
  String toString() => message;
}

/// ИИ-модуль. Все вызовы идут только по действию пользователя.
/// Ответы для слов кэшируются в БД, поэтому повторный просмотр офлайн бесплатен.
class AiService {
  static const _endpoint = 'https://api.anthropic.com/v1/messages';
  static const _timeout = Duration(seconds: 60);
  static const _system =
      'Ты преподаватель английского для русскоязычного ученика уровня B1–C1. '
      'Отвечай кратко и по делу.';

  final SecureStore store;
  final Db db;

  AiService({required this.store, required this.db});

  Future<bool> hasKey() async {
    final key = await store.readApiKey();
    return key != null && key.isNotEmpty;
  }

  /// Мнемоника: созвучие с русским словом и яркий образ.
  Future<String> mnemonic(WordRow w) => _cached(
        'mnemonic:${w.id}',
        'Придумай короткую мнемонику для слова или фразы "${w.word}" '
            '(значит: "${w.translation}"). Используй созвучие с русским словом '
            'и яркий образ. До 40 слов, без вступления.',
      );

  /// Три новых примера в разных ситуациях, с переводом.
  Future<String> moreExamples(WordRow w) => _cached(
        'examples:${w.id}',
        'Дай 3 новых коротких примера на английском со словом или фразой '
            '"${w.word}" (значит: "${w.translation}"). Разные ситуации: бытовая, '
            'рабочая, разговорная. Каждый пример с новой строки, без нумерации, '
            'перевод на русский в скобках после примера.',
      );

  /// Разбор фразы ученика. Не кэшируется.
  Future<String> checkSentence(WordRow w, String sentence) => _ask(
        'Ученик написал фразу "$sentence", используя "${w.word}". '
            'Если ошибок нет, так и скажи и предложи более естественный вариант. '
            'Если есть ошибки, покажи исправленную фразу и коротко объясни каждую '
            'по-русски. До 80 слов.',
      );

  /// Пакет слов: перевод и два примера. Возвращает готовые записи для БД.
  Future<List<SeedWord>> enrichWords(List<String> words) async {
    final text = await _ask(
      'Для каждого слова из списка дай перевод на русский (1–2 основных значения '
      'через запятую) и два коротких примера на английском уровня B1. Фразовые '
      'глаголы и коллокации сохраняй целиком. Верни ТОЛЬКО JSON-массив без '
      'пояснений и без markdown в формате '
      '[{"word":"...","translation":"...","examples":["...","..."]}]. '
      'Слова: ${words.join(', ')}',
      maxTokens: 4000,
    );
    return _parseWords(text);
  }

  List<SeedWord> _parseWords(String text) {
    final start = text.indexOf('[');
    final end = text.lastIndexOf(']');
    if (start < 0 || end <= start) {
      throw AiException('Ответ сервиса не в формате JSON.');
    }
    final list = jsonDecode(text.substring(start, end + 1)) as List;
    final out = <SeedWord>[];
    for (final item in list) {
      if (item is! Map) continue;
      final word = (item['word'] as String?)?.trim().toLowerCase();
      final tr = (item['translation'] as String?)?.trim();
      final ex = (item['examples'] as List?)?.whereType<String>().toList() ??
          <String>[];
      if (word == null || word.isEmpty || tr == null || tr.isEmpty) continue;
      out.add(SeedWord(word, tr, ex));
    }
    if (out.isEmpty) throw AiException('Сервис не вернул ни одного слова.');
    return out;
  }

  Future<String> _cached(String key, String prompt) async {
    final cached = await db.getAi(key);
    if (cached != null) return cached;
    final text = await _ask(prompt);
    await db.putAi(key, text);
    return text;
  }

  Future<String> _ask(String prompt, {int maxTokens = 400}) async {
    final key = await store.readApiKey();
    if (key == null || key.isEmpty) {
      throw AiException('Ключ API не задан. Добавьте его в настройках.');
    }
    final model = await store.readModel();

    final response = await http
        .post(
          Uri.parse(_endpoint),
          headers: {
            'x-api-key': key,
            'anthropic-version': '2023-06-01',
            'content-type': 'application/json',
          },
          body: jsonEncode({
            'model': model,
            'max_tokens': maxTokens,
            'system': _system,
            'messages': [
              {'role': 'user', 'content': prompt},
            ],
          }),
        )
        .timeout(_timeout);

    if (response.statusCode != 200) {
      throw AiException(
          'Ошибка API: код ${response.statusCode}. Проверьте ключ и модель в настройках.');
    }

    final data =
        jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    final blocks = (data['content'] as List?) ?? const [];
    final text = blocks
        .whereType<Map<String, dynamic>>()
        .where((b) => b['type'] == 'text')
        .map((b) => b['text'] as String)
        .join()
        .trim();

    if (text.isEmpty) throw AiException('Пустой ответ от сервиса.');
    return text;
  }
}
