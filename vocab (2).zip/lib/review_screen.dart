import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

import 'ai_service.dart';
import 'db.dart';
import 'settings_screen.dart';
import 'srs.dart';

class ReviewScreen extends StatefulWidget {
  final Db db;
  final AiService ai;
  const ReviewScreen({super.key, required this.db, required this.ai});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  final _tts = FlutterTts();
  final _input = TextEditingController();

  List<WordRow> _queue = [];
  int _index = 0;
  bool _revealed = false;
  bool _loading = true;
  bool _aiBusy = false;
  String _feedback = '';
  String _aiTitle = '';
  String? _aiResult;

  @override
  void initState() {
    super.initState();
    _tts.setLanguage('en-US');
    _load();
  }

  @override
  void dispose() {
    _tts.stop();
    _input.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final rows = await widget.db
        .dueWords(DateTime.now().millisecondsSinceEpoch, limit: 20);
    if (!mounted) return;
    setState(() {
      _queue = rows;
      _index = 0;
      _loading = false;
      _resetCard();
    });
  }

  void _resetCard() {
    _revealed = false;
    _feedback = '';
    _aiTitle = '';
    _aiResult = null;
    _input.clear();
  }

  WordRow get _current => _queue[_index];

  void _check() {
    final typed = _input.text.trim();
    final correct = typed.toLowerCase() == _current.word.toLowerCase();
    setState(() {
      _revealed = true;
      _feedback = correct ? 'Верно!' : 'Вы написали: "$typed"';
    });
    _tts.speak(_current.word);
  }

  Future<void> _grade(Grade g) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final updated = review(_current.state, g, now);
    await widget.db.saveReview(_current.id, updated);
    if (!mounted) return;
    setState(() {
      _index++;
      if (_index < _queue.length) _resetCard();
    });
  }

  /// Единая точка для всех ИИ-действий: состояние загрузки, ошибки, защита от смены карточки.
  Future<void> _runAi(String title, Future<String> Function() action) async {
    final word = _current;
    setState(() {
      _aiBusy = true;
      _aiTitle = title;
      _aiResult = null;
    });
    try {
      final text = await action();
      if (!mounted || _index >= _queue.length || _current.id != word.id) {
        return; // пользователь уже перешёл к другой карточке
      }
      setState(() => _aiResult = text);
    } on AiException catch (e) {
      _snack(e.message);
    } catch (_) {
      _snack('Нет связи с сервисом. Повторение работает и без него.');
    } finally {
      if (mounted) setState(() => _aiBusy = false);
    }
  }

  Future<void> _askSentence() async {
    final word = _current;
    final sentence = await showDialog<String>(
      context: context,
      builder: (ctx) {
        final controller = TextEditingController();
        return AlertDialog(
          title: Text('Фраза со словом "${word.word}"'),
          content: TextField(
            controller: controller,
            autofocus: true,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: 'Напишите своё предложение',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, controller.text.trim()),
              child: const Text('Проверить'),
            ),
          ],
        );
      },
    );
    if (sentence == null || sentence.isEmpty) return;
    await _runAi(
      'Разбор фразы',
      () => widget.ai.checkSentence(word, sentence),
    );
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  void _openSettings() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SettingsScreen(store: widget.ai.store),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;

    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_index >= _queue.length) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Повторение'),
          actions: [
            IconButton(icon: const Icon(Icons.settings), onPressed: _openSettings),
          ],
        ),
        body: const Center(child: Text('На сегодня всё 🎉')),
      );
    }

    final w = _current;

    return Scaffold(
      appBar: AppBar(
        title: Text('${_index + 1} / ${_queue.length}'),
        actions: [
          IconButton(icon: const Icon(Icons.settings), onPressed: _openSettings),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(w.translation, style: theme.headlineSmall),
          const SizedBox(height: 16),
          TextField(
            controller: _input,
            enabled: !_revealed,
            autofocus: true,
            decoration: const InputDecoration(
              labelText: 'Напишите слово по-английски',
              border: OutlineInputBorder(),
            ),
            onSubmitted: (_) => _check(),
          ),
          const SizedBox(height: 12),
          if (!_revealed)
            FilledButton(onPressed: _check, child: const Text('Проверить')),
          if (_revealed) ...[
            if (_feedback.isNotEmpty) Text(_feedback, style: theme.titleMedium),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: Text(w.word, style: theme.headlineMedium)),
                IconButton(
                  icon: const Icon(Icons.volume_up),
                  onPressed: () => _tts.speak(w.word),
                ),
              ],
            ),
            for (final e in w.examples)
              Row(
                children: [
                  Expanded(child: Text('• $e')),
                  IconButton(
                    icon: const Icon(Icons.volume_up, size: 18),
                    onPressed: () => _tts.speak(e),
                  ),
                ],
              ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: _aiBusy
                      ? null
                      : () => _runAi(
                            'Мнемоника',
                            () => widget.ai.mnemonic(w),
                          ),
                  icon: const Icon(Icons.auto_awesome, size: 18),
                  label: const Text('Мнемоника'),
                ),
                OutlinedButton.icon(
                  onPressed: _aiBusy
                      ? null
                      : () => _runAi(
                            'Ещё примеры',
                            () => widget.ai.moreExamples(w),
                          ),
                  icon: const Icon(Icons.format_quote, size: 18),
                  label: const Text('Ещё примеры'),
                ),
                OutlinedButton.icon(
                  onPressed: _aiBusy ? null : _askSentence,
                  icon: const Icon(Icons.edit_note, size: 18),
                  label: const Text('Проверить фразу'),
                ),
              ],
            ),
            if (_aiBusy)
              const Padding(
                padding: EdgeInsets.only(top: 12),
                child: LinearProgressIndicator(),
              ),
            if (_aiResult != null)
              Card(
                margin: const EdgeInsets.only(top: 12),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_aiTitle, style: theme.titleSmall),
                      const SizedBox(height: 6),
                      Text(_aiResult!),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 24),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _gradeButton('Снова', Grade.again),
                _gradeButton('Трудно', Grade.hard),
                _gradeButton('Хорошо', Grade.good),
                _gradeButton('Легко', Grade.easy),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _gradeButton(String label, Grade g) => OutlinedButton(
        onPressed: () => _grade(g),
        child: Text(label),
      );
}
