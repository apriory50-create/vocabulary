import 'package:flutter/material.dart';

import 'secure_store.dart';

class SettingsScreen extends StatefulWidget {
  final SecureStore store;
  const SettingsScreen({super.key, required this.store});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _keyController = TextEditingController();
  final _modelController = TextEditingController();
  bool _hasKey = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  void dispose() {
    _keyController.dispose();
    _modelController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    final key = await widget.store.readApiKey();
    final model = await widget.store.readModel();
    if (!mounted) return;
    setState(() {
      _hasKey = key != null && key.isNotEmpty;
      _modelController.text = model;
    });
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _save() async {
    final key = _keyController.text.trim();
    final model = _modelController.text.trim();
    if (key.isNotEmpty) await widget.store.writeApiKey(key);
    if (model.isNotEmpty) await widget.store.writeModel(model);
    _keyController.clear();
    await _refresh();
    _snack('Настройки сохранены на этом устройстве');
  }

  Future<void> _deleteKey() async {
    await widget.store.deleteApiKey();
    await _refresh();
    _snack('Ключ удалён');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Настройки')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Приложение работает офлайн. ИИ нужен для мнемоник, примеров, '
            'проверки фраз и загрузки колоды.',
            style: theme.bodyMedium,
          ),
          const SizedBox(height: 20),
          Text(
            _hasKey ? 'Ключ задан ✓' : 'Ключ не задан',
            style: theme.titleMedium,
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _keyController,
            obscureText: true,
            enableSuggestions: false,
            autocorrect: false,
            decoration: const InputDecoration(
              labelText: 'Ключ API (оставьте пустым, чтобы не менять)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _modelController,
            autocorrect: false,
            decoration: const InputDecoration(
              labelText: 'Модель',
              helperText: 'Например claude-haiku-5-5 или claude-sonnet-5-5',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          FilledButton(onPressed: _save, child: const Text('Сохранить')),
          const SizedBox(height: 8),
          if (_hasKey)
            TextButton(onPressed: _deleteKey, child: const Text('Удалить ключ')),
        ],
      ),
    );
  }
}
