class SeedWord {
  final String word;
  final String translation;
  final List<String> examples;

  const SeedWord(this.word, this.translation, this.examples);
}

/// Новые слова добавляйте сюда. При запуске уже существующие записи не меняются.
const seedWords = <SeedWord>[
  SeedWord('make a decision', 'принять решение', [
    'I need to make a decision by Friday.',
    'It was a hard decision to make.',
  ]),
  SeedWord('heavy rain', 'сильный дождь', [
    'We cancelled the trip because of heavy rain.',
    'The heavy rain flooded the streets.',
  ]),
  SeedWord('come up with', 'придумать', [
    'She came up with a clever solution.',
    'Can you come up with a better title?',
  ]),
  SeedWord('reluctant', 'неохотный', [
    'He was reluctant to admit his mistake.',
    'She seemed reluctant to join the meeting.',
  ]),
  SeedWord('ubiquitous', 'вездесущий', [
    'Smartphones have become ubiquitous.',
    'Coffee shops are ubiquitous in this city.',
  ]),
  SeedWord('get along with', 'ладить с', [
    'I get along well with my new colleagues.',
    'Do you get along with your neighbours?',
  ]),
  SeedWord('I was wondering if', 'мне интересно, не могли бы вы', [
    'I was wondering if you could help me.',
    'I was wondering if we could reschedule.',
  ]),
  SeedWord('decisive', 'решительный', [
    'She is decisive under pressure.',
    'A decisive move changed the outcome.',
  ]),
];
