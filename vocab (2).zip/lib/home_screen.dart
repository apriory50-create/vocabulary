import 'package:flutter/material.dart';

import 'ai_service.dart';
import 'db.dart';
import 'deck_builder.dart';
import 'grammar.dart';
import 'review_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final Db db;
  final AiService ai;
  const HomeScreen({super.key, required this.db, required this.ai});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _count = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await widget.db.countWords();
    if (!mounted) return;
    setState(() => _count = c);
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _openReview() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ReviewScreen(db: widget.db, ai: widget.ai),
      ),
    );
    _load();
  }

  Future<void> _importDeck() async {
    if (!await widget.ai.hasKey()) {
      _snack('Сначала добавьте ключ API в настройках');
      return;
    }

    final builder = DeckBuilder(db: widget.db, ai: widget.ai);
    final status = ValueNotifier<String>('Подготовка...');

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Загрузка колоды'),
        content: ValueListenableBuilder<String>(
          valueListenable: status,
          builder: (_, s, __) => Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(s),
              const SizedBox(height: 12),
              const LinearProgressIndicator(),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: builder.cancel,
            child: const Text('Остановить'),
          ),
        ],
      ),
    );

    String message;
    try {
      await builder.run(onStatus: (s) => status.value = s);
      message = status.value;
    } on AiException catch (e) {
      message = 'Остановлено с ошибкой: ${e.message}. Повторите, чтобы продолжить.';
    } catch (_) {
      message = 'Нет связи. Загрузка сохранена до текущего места, повторите позже.';
    } finally {
      // Закрываем именно диалог загрузки, он всегда на верхнем уровне.
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
      status.dispose();
    }

    await _load();
    _snack(message);
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SettingsScreen(store: widget.ai.store)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vocab'),
        actions: [
          IconButton(icon: const Icon(Icons.settings), onPressed: _openSettings),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Слов в колоде: $_count', style: theme.titleLarge),
          const SizedBox(height: 20),
          FilledButton(onPressed: _openReview, child: const Text('Повторение')),
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const GrammarScreen()),
            ),
            child: const Text('Грамматика'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _importDeck,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Загрузить колоду (ИИ)'),
          ),
          const SizedBox(height: 8),
          Text(
            'Берёт слова из assets/wordlist.txt, которых ещё нет в колоде, '
            'и добавляет перевод и примеры пакетами по 40.',
            style: theme.bodySmall,
          ),
        ],
      ),
    );
  }
}
