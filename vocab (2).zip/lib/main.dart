import 'package:flutter/material.dart';

import 'ai_service.dart';
import 'db.dart';
import 'home_screen.dart';
import 'secure_store.dart';
import 'seed.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final db = Db();
  await db.open();
  await db.seed(seedWords);

  final ai = AiService(store: SecureStore(), db: db);

  runApp(VocabApp(db: db, ai: ai));
}

class VocabApp extends StatelessWidget {
  final Db db;
  final AiService ai;
  const VocabApp({super.key, required this.db, required this.ai});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Vocab',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        home: HomeScreen(db: db, ai: ai),
      );
}
