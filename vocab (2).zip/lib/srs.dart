import 'dart:math';

const _dayMs = 86400000;
const _againDelayMs = 10 * 60 * 1000; // «снова» — вернуть через 10 минут

enum Grade { again, hard, good, easy }

class CardState {
  final double stability; // дни до заметного забывания
  final double difficulty; // 1 (легко) .. 10 (трудно)
  final int lastMs;
  final int dueMs;
  final int reps;
  final int lapses;

  const CardState({
    this.stability = 0,
    this.difficulty = 5,
    this.lastMs = 0,
    this.dueMs = 0,
    this.reps = 0,
    this.lapses = 0,
  });
}

/// Упрощённый планировщик в духе FSRS. Чистая функция: удобно тестировать.
CardState review(CardState s, Grade g, int nowMs) {
  final newDifficulty =
      (s.difficulty + (2 - g.index) * 0.4).clamp(1.0, 10.0).toDouble();

  double newStability;
  var lapses = s.lapses;

  if (s.reps == 0) {
    newStability = const [0.4, 1.0, 2.5, 5.0][g.index];
  } else {
    final elapsedDays = max(0.0, (nowMs - s.lastMs) / _dayMs);
    final retrievability = exp(-elapsedDays / max(s.stability, 0.01));

    if (g == Grade.again) {
      lapses++;
      newStability = max(0.3, s.stability * 0.2);
    } else {
      const bonus = [0.0, 0.2, 1.0, 1.6]; // снова, трудно, хорошо, легко
      final easeFactor = (11 - newDifficulty) / 10;
      final spacing = 1 + (1 - retrievability);
      newStability = s.stability * (1 + bonus[g.index] * easeFactor * spacing);
    }
  }

  final delayMs =
      g == Grade.again ? _againDelayMs : (newStability * _dayMs).round();

  return CardState(
    stability: newStability,
    difficulty: newDifficulty,
    lastMs: nowMs,
    dueMs: nowMs + delayMs,
    reps: s.reps + 1,
    lapses: lapses,
  );
}
