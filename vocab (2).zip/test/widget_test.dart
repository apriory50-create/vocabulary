// Имя widget_test.dart нужно, чтобы `flutter create` не подставил шаблонный тест
// с MyApp, который не компилируется с этим приложением.
import 'package:flutter_test/flutter_test.dart';
import 'package:vocab/grammar.dart';

void main() {
  test('каждая тема грамматики содержит правило, примеры и упражнения', () {
    expect(grammarTopics, isNotEmpty);
    for (final t in grammarTopics) {
      expect(t.rule.trim(), isNotEmpty, reason: t.title);
      expect(t.examples, isNotEmpty, reason: t.title);
      expect(t.exercises, isNotEmpty, reason: t.title);
      for (final e in t.exercises) {
        expect(e.answer.trim(), isNotEmpty, reason: t.title);
      }
    }
  });
}
