import 'package:flutter_test/flutter_test.dart';
import 'package:vocab/srs.dart';

const _day = 86400000;

void main() {
  test('новое слово, оценка «хорошо»: интервал 2.5 дня', () {
    final s = review(const CardState(), Grade.good, 0);
    expect(s.stability, closeTo(2.5, 1e-9));
    expect(s.dueMs, (2.5 * _day).round());
    expect(s.reps, 1);
  });

  test('«снова» сбрасывает интервал и увеличивает число провалов', () {
    final s1 = review(const CardState(), Grade.good, 0);
    final s2 = review(s1, Grade.again, s1.dueMs);
    expect(s2.lapses, 1);
    expect(s2.stability, lessThan(s1.stability));
    expect(s2.dueMs - s2.lastMs, 10 * 60 * 1000);
  });

  test('повторные успехи растят интервал', () {
    var s = review(const CardState(), Grade.good, 0);
    final first = s.stability;
    s = review(s, Grade.good, s.dueMs);
    expect(s.stability, greaterThan(first));
  });
}
